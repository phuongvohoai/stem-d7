<?php
/**
 * @file
 * Handles the layout of the short_answer answering form.
 *
 *
 * Variables available:
 * - $form
 */
print drupal_render($form);

?>