<?php
/**
 * @file
 * Handles the layout of the long_answer answering form.
 *
 *
 * Variables available:
 * - $form
 */
print drupal_render_children($form);

?>
