<?php
/**
 * @file
 * Handles the layout of the matching answering form.
 *
 *
 * Variables available:
 * - $form
 */
print drupal_render($form);

?>