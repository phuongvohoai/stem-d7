<?php
/**
 * @file
 * Handles the layout of the scale answering form.
 *
 *
 * Variables available:
 * - $form
 */
print drupal_render($form);

?>